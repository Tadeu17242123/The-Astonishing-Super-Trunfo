var carta1 = {
    nome: "FAYTHE",
    imagem: "https://pm1.narvii.com/6206/408167e47fde5bbead561a17d737ec92af571e7f_hq.jpg",
    atributos: {
        ataque: 80,
        defesa: 60,
        magia: 90
    }
}

var carta2 = {
    nome: "Nafaryus",
    imagem: "https://pm1.narvii.com/6206/da9aa9306c5ba32fb4024c6fa0baafce66639b4c_hq.jpg",
    atributos: {
        ataque: 70,
        defesa: 65,
        magia: 85
    }
}

var carta3 = {
    nome: "Daryus",
    imagem: "https://pm1.narvii.com/6206/ae9d7fd733f6c250d8921184bf8348286426cf75_hq.jpg",
    atributos: {
        ataque: 88,
        defesa: 62,
        magia: 90
    }
}
var carta4 = {
    nome: "Gabriel",
    imagem: "https://pm1.narvii.com/6206/35ceea529cfd74e5aff2eadc233d9bf42b8b9496_hq.jpg",
    atributos: {
        ataque: 98,
        defesa: 79,
        magia: 84
    }
}

var carta5 = {
    nome: "Arabelle",
    imagem: "https://pm1.narvii.com/6206/d391bbb0a885a42c08eca827e74c1689ee7965ae_hq.jpg",
    atributos: {
        ataque: 84,
        defesa: 65,
        magia: 97
    }
}

var carta6 = {
    nome: "Xander",
    imagem: "https://pm1.narvii.com/6206/db19940e13667895234d88eef2df13fc01f518c4_hq.jpg",
    atributos: {
        ataque: 71,
        defesa: 65,
        magia: 100
    }
}

var carta7 = {
    nome: "Arhys",
    imagem: "https://pm1.narvii.com/6206/6d512c1c0bd52b41812ffa3f0efc5c7908d879ab_hq.jpg",
    atributos: {
        ataque: 90,
        defesa: 64,
        magia: 87
    }
}

var carta8 = {
    nome: "Evangeline",
    imagem: "https://pm1.narvii.com/6206/fc3a8f36dc6bace0b0e1eb14ec7886fdb5db1e3e_hq.jpg",
    atributos: {
        ataque: 100,
        defesa: 75,
        magia: 95
    }
}

var carta9= {
    nome: "Eventos",
    imagem: "https://dreamtheater.net/wp-content/uploads/2017/10/astonishing-novel-background.jpg",
    atributos: {
        ataque: 56,
        defesa: 65,
        magia: 97
    }
}
var carta10= {
    nome: "Dream Teather",
    imagem: "https://images-na.ssl-images-amazon.com/images/I/51VZdJZqSfL._SY498_BO1,204,203,200_.jpg",
    atributos: {
        ataque: 97,
        defesa: 89,
        magia: 98
    }
}

var carta11= {
    nome: "Máquinas",
    imagem: "https://i.ytimg.com/vi/CdPn1mCmqoE/maxresdefault.jpg",
    atributos: {
        ataque: 99,
        defesa: 68,
        magia: 55
    }
}

var carta12= {
    nome: "City",
    imagem: "https://progressivemusicplanet.files.wordpress.com/2016/01/dream-theater-the-gift-of-music.jpg?w=640",
    atributos: {
        ataque: 43,
        defesa: 55,
        magia: 87
    }
}

var carta13= {
    nome: "Fortaleza",
    imagem: "https://www.radiorock.com.br/wp-content/uploads/2016/02/dream-theater-game-destaque.jpg",
    atributos: {
        ataque: 76,
        defesa: 45,
        magia: 78
    }
}

var carta14= {
    nome: "Mapa",
    imagem: "https://i0.wp.com/dreamtheater.club/wp-content/uploads/2016/01/map_final.jpg?resize=993%2C680&ssl=1",
    atributos: {
        ataque: 68,
        defesa: 89,
        magia: 66
    }
}



var cartaMaquina
var cartaJogador
var cartas = [carta1, carta2, carta3, carta4,carta5,carta6,carta7,carta8,carta9,carta10,carta11,carta12,carta13,carta14]
// 0          1           2

var pontosJogador = 0
var pontosMaquina = 0

atualizaPlacar()
atualizaQuantidadeDeCartas()

function atualizaQuantidadeDeCartas() {
    var divQuantidadeCartas = document.getElementById('quantidade-cartas')
    var html = "Quantidade de cartas no jogo: " + cartas.length

    divQuantidadeCartas.innerHTML = html
}

function atualizaPlacar() {
    var divPlacar = document.getElementById('placar')
    var html = "Jogador " + pontosJogador + "/" + pontosMaquina + " Máquina"

    divPlacar.innerHTML = html
}

function sortearCarta() {
    var numeroCartaMaquina = parseInt(Math.random() * cartas.length)
    cartaMaquina = cartas[numeroCartaMaquina]
    cartas.splice(numeroCartaMaquina, 1)

    var numeroCartaJogador = parseInt(Math.random() * cartas.length)
    cartaJogador = cartas[numeroCartaJogador]
    cartas.splice(numeroCartaJogador, 1)

    document.getElementById('btnSortear').disabled = true
    document.getElementById('btnJogar').disabled = false

    exibeCartaJogador()
}

function exibeCartaJogador() {
    var divCartaJogador = document.getElementById("carta-jogador")
    var moldura = '<img src="https://i.ibb.co/4NTr8Cr/8.png" style=" width: inherit; height: inherit; position: absolute;">';
    divCartaJogador.style.backgroundImage = `url(${cartaJogador.imagem})`
    var nome = `<p class="carta-subtitle">${cartaJogador.nome}</p>`
    var opcoesTexto = ""

    for (var atributo in cartaJogador.atributos) {
        opcoesTexto += "<input type='radio' name='atributo' value='" + atributo + "'>" + atributo + " " + cartaJogador.atributos[atributo] + "<br>"
    }

    var html = "<div id='opcoes' class='carta-status'>"

    divCartaJogador.innerHTML = moldura + nome + html + opcoesTexto + '</div>'
}

function obtemAtributoSelecionado() {
    var radioAtributo = document.getElementsByName('atributo')
    for (var i = 0; i < radioAtributo.length; i++) {
        if (radioAtributo[i].checked) {
            return radioAtributo[i].value
        }
    }
}

function jogar() {
    var divResultado = document.getElementById("resultado")
    var atributoSelecionado = obtemAtributoSelecionado()

    if (cartaJogador.atributos[atributoSelecionado] > cartaMaquina.atributos[atributoSelecionado]) {
        htmlResultado = '<p class="resultado-final">Venceu</p>'
        pontosJogador++
    } else if (cartaJogador.atributos[atributoSelecionado] < cartaMaquina.atributos[atributoSelecionado]) {
        htmlResultado = '<p class="resultado-final">Perdeu</p>'
        pontosMaquina++
    } else {
        htmlResultado = '<p class="resultado-final">Empatou</p>'
    }

    if (cartas.length == 0) {
        alert("Fim de jogo")
        if (pontosJogador > pontosMaquina) {
            htmlResultado = '<p class="resultado-final">Venceu</p>'
        } else if (pontosMaquina > pontosJogador) {
            htmlResultado = '<p class="resultado-final">Perdeu</p>'
        } else {
            htmlResultado = '<p class="resultado-final">Empatou</p>'
        }
    } else {
        document.getElementById('btnProximaRodada').disabled = false
    }

    divResultado.innerHTML = htmlResultado
    document.getElementById('btnJogar').disabled = true

    atualizaPlacar()
    exibeCartaMaquina()
    atualizaQuantidadeDeCartas()
}

function exibeCartaMaquina() {
    var divCartaMaquina = document.getElementById("carta-maquina")
    var moldura = '<img src="https://i.ibb.co/4NTr8Cr/8.png" style=" width: inherit; height: inherit; position: absolute;">';
     divCartaMaquina.style.backgroundImage = `url(${cartaMaquina.imagem})`
    var nome = `<p class="carta-subtitle">${cartaMaquina.nome}</p>`
    var opcoesTexto = ""

    for (var atributo in cartaMaquina.atributos) {
        console.log(atributo)
        opcoesTexto += "<p type='text' name='atributo' value='" + atributo + "'>" + atributo + " " + cartaMaquina.atributos[atributo] + "<br>"
    }

    var html = "<div id='opcoes' class='carta-status --spacing'>"

    divCartaMaquina.innerHTML = moldura + nome + html + opcoesTexto + '</div>'
}

function proximaRodada() {
    var divCartas = document.getElementById('cartas')

    divCartas.innerHTML = `<div id="carta-jogador" class="carta"></div> <div id="carta-maquina" class="carta"></div>`

    document.getElementById('btnSortear').disabled = false
    document.getElementById('btnJogar').disabled = true
    document.getElementById('btnProximaRodada').disabled = true

    var divResultado = document.getElementById('resultado')
    divResultado.innerHTML = ""
}